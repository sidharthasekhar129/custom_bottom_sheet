package com.example.custombottomsheet;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;

import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;

public class MainActivity extends AppCompatActivity {
    private Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=(Button)findViewById(R.id.btn);

      //  btn = findViewById(R.id.login);


        //get the bottom sheet view

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    LinearLayout    linearLayout = findViewById(R.id.buttt);
                    //init the bottom sheet view
                    BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(linearLayout);
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                }

            }
        });





      /*  btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BottomSheetDialog bottomSheetDialog=new BottomSheetDialog(MainActivity.this);
                bottomSheetDialog.setContentView(R.layout.buttomsheetdialog);
                bottomSheetDialog.setCanceledOnTouchOutside(false);
                final EditText username=bottomSheetDialog.findViewById(R.id.uname);
                final EditText password=bottomSheetDialog.findViewById(R.id.password);
                Button login=bottomSheetDialog.findViewById(R.id.login);
                login.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String username1=username.getText().toString();
                        String password1=password.getText().toString();

                        if (username1.equals("Sidhartha") && password1.equals("tina123"))
                        {
                            AlertDialog.Builder  builder=new AlertDialog.Builder(v.getContext());
                            builder.setTitle("Login Sucessful");
                            builder.setMessage("Welcome to Android Studio");
                            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // Toast.makeText(MainActivity.this, "Login canceled by user", Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();
                                }
                            }).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Toast.makeText(MainActivity.this, "Login Sucessfully", Toast.LENGTH_SHORT).show();
                                }
                            });
                            AlertDialog alertDialog =builder.create();
                            alertDialog.show();

                        }
                        else {
                            Toast.makeText(MainActivity.this, "Authentication Error", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                bottomSheetDialog.show();
            }
        });*/

    }
}

